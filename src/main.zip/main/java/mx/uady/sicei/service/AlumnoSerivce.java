package mx.uady.sicei.service;

import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Service;

import mx.uady.sicei.model.Alumno;
import mx.uady.sicei.model.request.AlumnoRequest;

@Service
public class AlumnoSerivce {

    private List<Alumno> alumnos = new LinkedList<>();

    {
        alumnos = new LinkedList<>();
        alumnos.add(new Alumno().id(1).nombre("Eduardo"));
        alumnos.add(new Alumno().id(2).nombre("Antonio"));
        alumnos.add(new Alumno().id(3).nombre("Brayan"));
    }

    public List<Alumno> getAlumnos() {
        return alumnos;
    }

    public Alumno crearAlumno(AlumnoRequest request) {
        Alumno alumno = new Alumno();

        alumno.setId(alumnos.size() + 1);
        alumno.setNombre(request.getNombre());
        alumnos.add(alumno);

        return alumno;
    }

    public Alumno obtenerAlumno(String id){
        int idAlumno =  Integer.parseInt(id);
        for(int i=0;i<alumnos.size();i++){
            if(alumnos.get(i).getId()==idAlumno){
                return alumnos.get(i);
            }
        }
        return null;
    }
    
    public Alumno actualizarAlumno(Integer id, AlumnoRequest request){
        for(int i=0;i<alumnos.size();i++){
            if(alumnos.get(i).getId()==id){
                alumnos.get(i).setNombre(request.getNombre());
                return alumnos.get(i);
            }
        }       
        return null;
    }

    public boolean borrarAlumno(Integer id){
     
        for(int i=0;i<alumnos.size();i++){
            if(alumnos.get(i).getId()==id){
                alumnos.remove(i);
                return true;
            }
        }
        return false;
    }
}
